# EV Charger Booking Backend

Backend API for an Electric Vehicle (EV) Charger Booking App built with Node.js, Express, TypeScript, and PostgreSQL, running in Docker containers.

## Features

- **User Management**: Registration and authentication with JWT tokens
- **Role-Based Access**: Three roles - User, Owner, and Admin
- **Booking System**: Time-based slot booking (1-hour slots)
- **Charger Management**: Owners can create booths and add chargers
- **Complaint System**: Users can raise complaints
- **Payment Tracking**: Payment records for bookings

## Tech Stack

- **Runtime**: Node.js 18
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: PostgreSQL 15
- **Containerization**: Docker & Docker Compose
- **Authentication**: JWT (JSON Web Tokens)

## Project Structure

```
ev-charger-backend/
├── src/
│   ├── config/          # Configuration files
│   │   └── database.ts  # PostgreSQL connection
│   ├── controllers/     # Request handlers
│   │   ├── authController.ts
│   │   └── bookingController.ts
│   ├── db/              # Database files
│   │   └── schema.sql   # Database schema
│   ├── middleware/      # Express middleware
│   │   └── auth.ts      # Authentication & authorization
│   ├── models/          # Data models
│   │   ├── User.ts
│   │   ├── Booth.ts
│   │   ├── Charger.ts
│   │   ├── Booking.ts
│   │   ├── Complaint.ts
│   │   └── Payment.ts
│   ├── routes/          # API routes
│   │   ├── authRoutes.ts
│   │   └── bookingRoutes.ts
│   ├── utils/           # Utility functions
│   ├── app.ts           # Express app setup
│   └── index.ts         # Application entry point
├── docker-compose.yml   # Docker Compose configuration
├── Dockerfile           # Node.js container definition
├── package.json        # Dependencies
├── tsconfig.json       # TypeScript configuration
└── .env                # Environment variables
```

## Quick Start

### Prerequisites

- Docker Desktop installed and running
- Docker Compose installed

### Setup

1. **Clone/Navigate to the project directory**
   ```bash
   cd ev-charger-backend
   ```

2. **Configure environment variables**
   - Copy `.env.example` to `.env` (already done)
   - Update values in `.env` if needed

3. **Build and start containers**
   ```bash
   docker-compose up --build
   ```

   This will:
   - Build the Node.js backend container
   - Start PostgreSQL database container
   - Automatically run the schema.sql to create tables
   - Start the Express server on port 3000

4. **Verify the setup**
   - Health check: `http://localhost:3000/health`
   - API is ready when you see: `Server is running on port 3000`

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login user

### Bookings

- `POST /api/bookings` - Create a new booking (requires authentication)
- `GET /api/bookings` - Get user's bookings (requires authentication)
- `GET /api/bookings/:id` - Get booking by ID (requires authentication)
- `PUT /api/bookings/:id/cancel` - Cancel a booking (requires authentication)

## Example Requests

### Register User
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123",
    "full_name": "John Doe",
    "phone": "+1234567890",
    "role": "user"
  }'
```

### Login
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "password123"
  }'
```

### Create Booking
```bash
curl -X POST http://localhost:3000/api/bookings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "charger_id": "charger-uuid",
    "booking_date": "2024-01-15",
    "start_time": "10:00:00",
    "end_time": "11:00:00"
  }'
```

## Database Schema

The database includes the following tables:
- **users** - User accounts with roles (user/owner/admin)
- **booths** - Charging booth locations
- **chargers** - Individual charging units
- **bookings** - Time-slot bookings
- **complaints** - User complaints
- **payments** - Payment records

## Development

### Running without Docker

```bash
# Install dependencies
npm install

# Start PostgreSQL locally or use Docker for DB only
docker-compose up postgres -d

# Run development server
npm run dev
```

### Building for production

```bash
npm run build
npm start
```

## Environment Variables

- `NODE_ENV` - Environment (development/production)
- `PORT` - Server port (default: 3000)
- `DB_HOST` - Database host
- `DB_PORT` - Database port (default: 5432)
- `DB_USER` - Database username
- `DB_PASSWORD` - Database password
- `DB_NAME` - Database name
- `JWT_SECRET` - Secret key for JWT tokens

## Notes

- The schema.sql file is automatically executed when the PostgreSQL container starts
- All bookings use 1-hour time slots
- Bookings prevent overlapping time slots for the same charger
- Owners require admin approval before they can create booths
- JWT tokens expire after 7 days

## License

ISC

