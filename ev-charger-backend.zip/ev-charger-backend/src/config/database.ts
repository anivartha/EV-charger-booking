/**
 * Database Configuration
 * Handles PostgreSQL connection and initialization
 */
import { Pool, PoolClient } from 'pg';
import fs from 'fs';
import path from 'path';

// Database connection pool
let pool: Pool;

/**
 * Initialize database connection pool
 */
export const initializeDatabase = (): Pool => {
  if (!pool) {
    pool = new Pool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432'),
      user: process.env.DB_USER || 'evcharger_user',
      password: process.env.DB_PASSWORD || 'evcharger_password',
      database: process.env.DB_NAME || 'evcharger_db',
      max: 20, // Maximum number of clients in the pool
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    // Handle pool errors
    pool.on('error', (err) => {
      console.error('Unexpected error on idle client', err);
    });
  }

  return pool;
};

/**
 * Get database connection from pool
 */
export const getDb = (): Pool => {
  if (!pool) {
    return initializeDatabase();
  }
  return pool;
};

/**
 * Execute a query and return results
 */
export const query = async (text: string, params?: any[]) => {
  const db = getDb();
  const start = Date.now();
  try {
    const res = await db.query(text, params);
    const duration = Date.now() - start;
    console.log('Executed query', { text, duration, rows: res.rowCount });
    return res;
  } catch (error) {
    console.error('Database query error', { text, error });
    throw error;
  }
};

/**
 * Execute a transaction
 */
export const transaction = async (callback: (client: PoolClient) => Promise<any>) => {
  const db = getDb();
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

/**
 * Test database connection
 */
export const testConnection = async (): Promise<boolean> => {
  try {
    const db = getDb();
    const result = await db.query('SELECT NOW()');
    console.log('Database connected successfully:', result.rows[0].now);
    return true;
  } catch (error) {
    console.error('Database connection failed:', error);
    return false;
  }
};

/**
 * Initialize database schema (runs schema.sql if not already executed)
 * Note: Schema is automatically executed by PostgreSQL init scripts,
 * but this function can be used to verify or re-run if needed
 */
export const initializeSchema = async (): Promise<void> => {
  try {
    // Test connection first
    await testConnection();
    
    // Schema is automatically loaded by PostgreSQL's init scripts
    // This is just a verification step
    const result = await query('SELECT table_name FROM information_schema.tables WHERE table_schema = \'public\'');
    console.log(`Database schema initialized. Tables found: ${result.rows.length}`);
    
    result.rows.forEach((row: any) => {
      console.log(`  - ${row.table_name}`);
    });
  } catch (error) {
    console.error('Error initializing schema:', error);
    throw error;
  }
};

